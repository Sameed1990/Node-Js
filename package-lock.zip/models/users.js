const mongoose = require("mongoose")


const Users = mongoose.Schema({
       username: { type: String, required: true, index:{unique:true} },
      email: { type: String, required: true, index:{unique:true} },
       password: { type: String, required: true },
       date:{type:Date, default: Date.now }
  
    })

const UserModel = mongoose.model("users", Users);

module.exports = UserModel;