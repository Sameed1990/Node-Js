const express = require('express');
const router = express.Router();
const path = require("path")
const jwt = require('jsonwebtoken');
const bcrypt = require("bcrypt")
const multer = require("multer")


// Models
const categoryModel = require("../models/category")
const ProductModel = require("../models/productmodel")
const UserModel = require("../models/users")


// Middlewares
const { CheckCategory } = require("../middlewares/CheckCategory")
const { CheckMail } = require("../middlewares/CheckMail")
const { CheckUser } = require("../middlewares/CheckUser")

router.use(express.static(__dirname + './public/'));



const Storage = multer.diskStorage({
  destination: "./public/uploads/",
  filename: (req, file, cb) => {
    cb(null, file.fieldname + "_" + Date.now() + path.extname(file.originalname))

  }
})

var upload = multer({
  storage: Storage
}).single('file');



/* GET home page. */
// router.get('/', function (req, res) {
//   return res.send('welcome to Express');
// });


router.get('/', function (req, res) {
  return res.render('workspace', { title: 'Express', msg: "", ll9: "" });
});
router.get('/account', function (req, res) {
  return res.render('account', { title: 'Express', msg: "", ll9: "" });
});
// router.get('/signup', function (req, res) {
//   return res.render('account', { title: 'Express', msg: "", ll9: "" });
// });
// router.get('/login', function (req, res) {
//   return res.render('account', { title: 'Express', msg: "", ll9: "" });
// });
router.get('/cart', function (req, res) {
  return res.render('cart', { title: 'Express', msg: "", ll9: "" });
});
// router.get('/products', function (req, res) {
//   return res.render('products', { title: 'Express', msg: "", ll9: "" });
// });
router.get('/products', async function (req, res) {
  var Get = await ProductModel.find({})
  console.log(Get);
  return res.render('products', { title: 'Express', products: Get });
});
router.get('/products/:category', async function (req, res) {
  const category = req.params.category;
  var Get = await ProductModel.find({ productCategory: category })
  console.log("Mens", Get);
  return res.render("products", { products: Get })
  // return res.json({ products: Get })

})
router.get('/products-details', function (req, res) {
  return res.render('Products-Details', { title: 'Express', msg: "", ll9: "" });
});
// router.get('/login', function (req, res) {
//   return res.render('login', { title: 'Express', msg: "", ll9: "" });
// });
// router.get('/signup', function (req, res) {
//   return res.render('signup', { title: 'Express', msg: "" });
// });
router.get('/add-category', function (req, res) {
  return res.render('AddCategory', { title: 'Express' });
});
router.get('/add-product', function (req, res) {
  return res.render('AddProduct', { title: 'Express', msg: "" });
});
router.get('/product', async function (req, res) {
  var Get = await ProductModel.find({})
  console.log(Get);
  return res.render('product', { title: 'Express', products: Get });
});

// router.get('/product/mens', async function(req, res) {
//   var Get = await ProductModel.find({productCategory:"Mens"})
//     console.log(Get);
//     return res.render('product', { title: 'Express' , products : Get});
//   });
// router.get('/product/:category?',async function (req, res) {

router.get('/product/:category', async function (req, res) {
  const category = req.params.category;
  var Get = await ProductModel.find({ productCategory: category })
  console.log("Mens", Get);
  return res.render("product", { products: Get })
  // return res.json({ products: Get })

})



router.post('/add-category', function (req, res) {
  const Category = new categoryModel({
    categoryName: req.body.Category
  })
  Category.save()
    .then(data => {
      return res.redirect('/add-category')
      console.log(data);
    })
    .catch(err => {
      console.log(err);
    })
});


router.post('/add-product', upload, CheckCategory, function (req, res, next) {
  var img = req.file.filename
  const AddProduct = new ProductModel({
    productName: req.body.Productname,
    productCategory: req.body.Productcat,
    Availability: req.body.Availability,
    Price: req.body.Price,
    Quantity: req.body.Quantity,
    Productimg: img
  })
  AddProduct.save()
    .then(data => {
      console.log(data);
      return res.redirect('/add-product')
    })
    .catch(err => {
      console.log(err);
    })
});

// router.post('/account', CheckMail, CheckUser, async (req, res) => {
  router.post('/account',  async (req, res) => {
  console.log("ok");

  if(req.body.myaction == "register") {
    var username = req.body.username
    var email = req.body.email
    var password = req.body.password
    // var confirm_password = req.body.con_password
  
    // if (password != confirm_password) {
    //   return res.render("account", { msg: "Password not match." })
    // }
  
    const encryptPassword = await bcrypt.hash(password, 10)
  
    var UserDetails = new UserModel({
      username: username,
      email: email,
      password: encryptPassword
    })
    UserDetails.save()
      .then(data => {
        console.log(data);
        return res.redirect(200, '/login')
      })
      .catch(err => {
        console.log(err);
        return res.render('account', { msg: "Error in registration" })
      })

  }
  else {
    var username = req.body.user
    var password = req.body.pass
  
    var CheckEmail = UserModel.findOne({ username: username })
      .then(data => {
        // console.log();
        console.log("data" ,data);
  
        if (data) {
          var GetUserName = data.username
          var GetUserEmail = data.email
          var GetUserId = data._id
          var getPassword = data.password
  
          bcrypt.compare(password, getPassword)
            .then(async isCorrect => {
              console.log("isCorrect" + isCorrect);
  
              if (isCorrect) {
                const payload = {
                  id: GetUserId,
                  email: GetUserEmail,
                  username: GetUserName,
                }
  
                jwt.sign(
                  payload,
                  process.env.JWT_SECRET,
                  {
                    expiresIn: 86400
                  },
                  (err, token) => {
                    if (err) return res.render('account', { title: 'Express', msg: 'Invalid email or password', ll9: "" });
                    // return res.json({
                    //   msg: "Login successfully",
                    //   token: `Bearer ${token}`
                    // })
  
                    console.log("token =>", `Bearer ${token}`);
  
                    return res.render('account', { title: 'Express', msg: '', ll9: `Bearer ${token}` });
  
                    // return res.redirect('/product');
  
                  }
                )
  
              } else {
                return res.render('account', { title: 'Express', msg: 'Invalid email or password', ll9: "" });
  
              }
              // return res.redirect('dashboard');
              // return res.render('login', { title: 'Express', msg: 'Invalid Username or password' });
  
            })
  
        } else {
          return res.render('account', { title: 'Express', msg: 'Invalid email or password', ll9: "" });
  
        }
  
  
  
      })
      .catch(err => {
        console.log(err);
        return res.render('account', { title: 'Express', msg: 'Invalid email or password', ll9: "" });
      })

  }


});


// router.post('/login', async function (req, res, next) {

//   console.log( req.body);

//   var username = req.body.user
//   var password = req.body.pass

//   var CheckEmail = UserModel.findOne({ username: username })
//     .then(data => {
//       // console.log();
//       console.log("data" ,data);

//       if (data) {
//         var GetUserName = data.username
//         var GetUserEmail = data.email
//         var GetUserId = data._id
//         var getPassword = data.password

//         bcrypt.compare(password, getPassword)
//           .then(async isCorrect => {
//             console.log("isCorrect" + isCorrect);

//             if (isCorrect) {
//               const payload = {
//                 id: GetUserId,
//                 email: GetUserEmail,
//                 username: GetUserName,
//               }

//               jwt.sign(
//                 payload,
//                 process.env.JWT_SECRET,
//                 {
//                   expiresIn: 86400
//                 },
//                 (err, token) => {
//                   if (err) return res.render('account', { title: 'Express', msg: 'Invalid email or password', ll9: "" });
//                   // return res.json({
//                   //   msg: "Login successfully",
//                   //   token: `Bearer ${token}`
//                   // })

//                   console.log("token =>", `Bearer ${token}`);

//                   return res.render('account', { title: 'Express', msg: '', ll9: `Bearer ${token}` });

//                   // return res.redirect('/product');

//                 }
//               )

//             } else {
//               return res.render('account', { title: 'Express', msg: 'Invalid email or password', ll9: "" });

//             }
//             // return res.redirect('dashboard');
//             // return res.render('login', { title: 'Express', msg: 'Invalid Username or password' });

//           })

//       } else {
//         return res.render('account', { title: 'Express', msg: 'Invalid email or password', ll9: "" });

//       }



//     })
//     .catch(err => {
//       console.log(err);
//       return res.render('account', { title: 'Express', msg: 'Invalid email or password', ll9: "" });
//     })
// });

router.get('/logout', (req, res) => {
  // sessionStorage.removeItem('Usertoken')
  // sessionStorage.removeItem('User')
  return res.redirect('/')
})


module.exports = router;